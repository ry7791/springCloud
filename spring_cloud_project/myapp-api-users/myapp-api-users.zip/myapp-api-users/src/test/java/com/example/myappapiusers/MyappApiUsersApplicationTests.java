package com.example.myappapiusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyappApiUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
