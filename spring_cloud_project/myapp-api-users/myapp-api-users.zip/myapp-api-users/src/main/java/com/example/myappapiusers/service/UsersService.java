package com.example.myappapiusers.service;

import com.example.myappapiusers.shared.UserDto;

public interface UsersService {
    UserDto createUser(UserDto userDetails);
}
