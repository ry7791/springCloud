package com.example.myappapiusers.model;

import lombok.Data;

@Data
public class LoginRequestModel {
}
